// SOCIAL MEDIA URL
global.group = 'https://chat.whatsapp.com/G6VyIzDhM3HCydXFPI3weu' // url WhatsApp group
global.saluran = 'https://whatsapp.com/channel/0029Vaqf1TF30LKNJw1A5V3g' // url WhatsApp channel
global.youtube = 'https://youtube.com/@BG-DARWIN' // url YouTube 
global.instagram = 'https://instagram.com/memek/' // url Instagram 

// PANEL DOMAIN
// app log, change if u have
global.applog = 'apy.pw/dalwingshop'
// domain panel
global.domain = 'https://yesus-hitam.online-server.biz.id' // isi domain panel anda
