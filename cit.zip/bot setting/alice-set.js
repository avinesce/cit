// CREATOR OPTION
global.namaownernya = 'Apin' // owner name
global.author = 'Apin' // your name
global.owner = '6283153759923@s.whatsapp.net' // akses owner
global.owner2 = '6283153759923' // nomor owner
global.email = 'kenagrace21@gmail.com' // optional

// INFO BOT
global.botchar = 'Alice' // nama karakter bot anda
global.aliceversion = '[ v 2.7 ]' // versi bot
global.namebot = 'ALICE ZUBERG' // nama bot
global.packname = '© Powered By Alice' // watermark
global.namechannel = 'PROJECT ALICEZATION' // your WhatsApp channel name
global.idgc = "120363338656932492@g.us" // opsional ID group, ubah jika bisa
global.idsal = "120363344309007219@newsletter" // opsional ID channel, ubah jika bisa
global.autodeletemessagebot = 600000 // hapus pesan yang sudah di kirim bot ( 1000 = 1 detik )

// UI BOT
global.menu = {
    block: '⏣',
    line: '┈──────────────────────',
    leftcorner: '⏤͟͟͞͞ᵡ',
    rightcorner: 'ᵡ͟͟͞͞⏤'
}

// TELE BOT SET
global.idowner = '6141098270' // isi ID telegram anda, ambil ID di t.me/myidbot
global.idgroup = '' // opsional, isi ID dengan id group/channel anda
global.userowner = '@DalwinOfficial' // isi dengan username telegram anda
global.nameongner = global.author // otomatis dengan nama author
global.ownertele = ["https://t.me/DalwinOfficial", "https://t.me/DalwinOfficial"] // pastikan username sudah sesuai agar fitur khusus owner bisa di pakai
global.token = '6622400099:AAEUpL7fRlgZhkvxbj5h98XYUSBoqpl8NGs';  // isi dengan token bot anda, buat token di t.me/botfather


// SETTING BOT
global.prefix = ['.']
global.autoreact = true // beri 1 reaksi ke setiap pesan baru
global.autobot = false // aktivasi bot clone secara otomatis jika ada session terkoneksi
global.public = true // mode semua pengguna, true untuk public
global.autoreadsw = true // meneruskan status dari nomor bot
global.autoread = true // auto baca pesan pengguna
global.autobio = true // perubahan bio otomatis dengan uptime bot secara real time
global.chatgpt = false // auto chat gpt reply, balasan ai otomatis
global.simisimi = false // auto simi reply
global.welcome = true // sistem welcome group anggota baru otomatis
global.onlygc = false // fungsi hanya untuk group chat
global.onlypc = false // fungsi hanya untuk private chat
global.game = true // guna agar command game bisa dimatikan/diaktifkan
global.autoreject = true // auto reject, blokir nomor penelpon bot
global.antilink = true // antilink, hapus semua pesan berupa link / domain
global.antiSpam = true // belum di beri fungsi
global.antibot = true // belum di beri fungsi
global.autojoin = false  // mode jelajah, bergabung otomatis tanpa command
global.boostgc = false // jumlah member dengan title group secara real time
global.autodelete = false // hapus semua tipe pesan otomatis group & pivate
global.autodonlod = false // guna download file tanpa command awal
global.autoTyping = true // composing mengetik saat melakukan perintah atau pesan baru
global.pengingat = false // notif sistem otomatis
global.tekspushkonv2 = '' // gunakan teks ini jika user tidak mengisi teks
global.select = 1 // opsi pilihan untuk polling bot
